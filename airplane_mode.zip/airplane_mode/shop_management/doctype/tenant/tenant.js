// Copyright (c) 2024, Yogita and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Tenant", {
// 	refresh(frm) {

// 	},
// });
