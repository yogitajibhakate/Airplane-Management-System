import frappe

def get_context(context):
	pass
